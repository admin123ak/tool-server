<?php

namespace App\Controllers;

use App\Models\KeysModel;

// ================= CONFIG LOG =================
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');
error_reporting(E_ALL);

function writeLog($message) {
    $time = date('Y-m-d H:i:s');
    error_log("[$time] $message");
}

class Connect extends BaseController
{
    protected $model, $game, $uKey, $sDev;
    protected $FIXED_TOKEN = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9EVm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";

    public function __construct()
    {
        include('conn.php');
//=================================================
        $sql1 ="select * from onoff where id=1";
        $result1 = mysqli_query($conn, $sql1);
        $userDetails1 = mysqli_fetch_assoc($result1);
//=================================================
        $this->model = new KeysModel();
//=================================================
        if($userDetails1['status'] == 'on')
        {
            $this->maintenance = true;
        } else {
            $this->maintenance = false;
        }
//=================================================
       $this->staticWords = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";
    }

    public function index()
    {
        // ================= DETECT BROWSER =================
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $isBrowser = preg_match('/(Mozilla|Chrome|Safari|Firefox|Edge|Opera)/i', $userAgent);

        if ($isBrowser && !isset($_SERVER['HTTP_X_API_CLIENT'])) {
            // Chỉ hiển thị lời chào cho browser
            header('Content-Type: text/html; charset=utf-8');
            echo 'Chào em nha';
            exit;
        }

        header('Content-Type: application/json; charset=utf-8');
        header("Cache-Control: no-store, no-cache, must-revalidate");

        // Check if there's any body content (for text/plain raw requests)
        $rawBody = $this->request->getBody();
        if (!empty($rawBody) || $this->request->getPost() || $this->request->getJSON()) {
            return $this->index_post();
        } else {
            return $this->response->setJSON([
                "status" => false,
                "message" => "No data provided"
            ]);
        }
    }

    // Helper function to return RC4-encrypted error responses
    private function returnError($message, $status = false) {
        $rc4Key = "K9mXp2Lq7Wn4Yt5R";
        $errorData = [
            "status" => $status,
            "message" => $message
        ];
        $errorJson = json_encode($errorData);
        $rc4Encrypted = $this->rc4($errorJson, $rc4Key);
        $finalResponse = base64_encode($rc4Encrypted);
        
        return $this->response
            ->setContentType('text/plain')
            ->setBody($finalResponse);
    }

    public function index_post()
    {
        $isMT = $this->maintenance;
        
        // Get raw input and decrypt RC4 layer
        $rawInput = $this->request->getBody();
        if (empty($rawInput)) {
            return $this->returnError("No data provided");
        }
        
        $rc4Key = "K9mXp2Lq7Wn4Yt5R";
        $rc4Decrypted = $this->rc4(base64_decode($rawInput), $rc4Key);
        
        if (empty($rc4Decrypted)) {
            return $this->returnError("Invalid request format");
        }
        
        $input = json_decode($rc4Decrypted, true);
        
        if (!$input) {
            return $this->returnError("Invalid request format");
        }

        $clientHeader = $this->request->getHeaderLine('X-API-Client');
        if ($clientHeader !== 'NativeApp') {
            return $this->returnError("Yêu cầu kết nối an toàn");
        }

        // Encrypted requests only (no legacy fallback)
        if (!isset($input['x'], $input['y'], $input['z'], $input['s'])) {
            return $this->returnError("Yêu cầu kết nối an toàn");
        }

        $encryptedData = $input['x'];
        $timestamp = $input['y'];
        $nonce = $input['z'];
        $mac = $input['s'];

        // Re-generate session key using timestamp + FIXED_TOKEN
        $sessionKey = $this->generateSessionKey($this->FIXED_TOKEN, $timestamp);

        if (abs(time() - intval($timestamp)) > 300) {
            return $this->returnError("Request Expired");
        }

        $expectedMac = $this->hmacBase64($sessionKey, $encryptedData . "|" . $timestamp . "|" . $nonce);
        if (!hash_equals($expectedMac, $mac)) {
            return $this->returnError("Invalid MAC");
        }

        $decryptedJson = $this->xxtea_decrypt($encryptedData, $sessionKey);
        $requestData = json_decode($decryptedJson, true);
        if (!$requestData) {
            return $this->returnError("Decryption Failed");
        }

        // Map variables
        $game = $requestData['game'] ?? null;
        $uKey = $requestData['key'] ?? null;
        $sDev = $requestData['hwid'] ?? null;
        $publicKey = $requestData['publicKey'] ?? null;

        // ================= VALIDATE REQUEST =================
        // Manual validation since data comes from decrypted JSON, not POST
        if (empty($game) || empty($uKey) || empty($sDev) || empty($publicKey)) {
            return $this->returnError("Bad Parameter");
        }
        
        if (strlen($uKey) > 36 || strlen($uKey) < 1) {
            return $this->returnError("Bad Parameter");
        }
        
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $game)) {
            return $this->returnError("Bad Parameter");
        }
        
        // ================= VALIDATE TOKEN =================
        if ($publicKey !== $this->FIXED_TOKEN) {
            return $this->returnError("Invalid public key");
        }

        // Validate timestamp to prevent replay attacks
        if ($timestamp) {
            $timeDiff = abs(time() - intval($timestamp));
            if ($timeDiff > 300) { // 5 minutes
                return $this->returnError("Request expired");
            }
        }

        if ($isMT) {
            include('conn.php');
            $sql1 ="select * from onoff where id=1";
            $result1 = mysqli_query($conn, $sql1);
            $userDetails1 = mysqli_fetch_assoc($result1);

            $responseData = [
                'status' => true,
                'message' => $userDetails1['myinput']
            ];
        } else {
            if (!$game || !$uKey || !$sDev) {
                $responseData = [
                    'status' => false,
                    'message' => 'INVALID PARAMETER'
                ];
            } else {
                $time = new \CodeIgniter\I18n\Time;
                $model = $this->model;
                $findKey = $model->getKeysGame(['user_key' => $uKey, 'game' => $game]);

                if ($findKey) {
                    if ($findKey->status != 1) {
                        $responseData = ['status' => false, 'message' => 'KEY LOCKED'];
                    } else {
                        $id_keys = $findKey->id_keys;
                        $duration = $findKey->duration;
                        $expired = $findKey->expired_date;

                        if (!$expired) {
                            $setExpired = $time::now()->addHours($duration);
                            $model->update($id_keys, ['expired_date' => $setExpired]);
                            $responseData['status'] = true;
                        } else {
                            if ($time::now()->isBefore($expired)) {
                                $responseData['status'] = true;
                            } else {
                                $responseData = [
                                    'status' => false,
                                    'message' => 'KEY EXPIRADA!'
                                ];
                            }
                        }

                        if (isset($responseData['status']) && $responseData['status']) {
                            include('conn.php');

                            $sql2 ="select * from modname where id=1";
                            $result2 = mysqli_query($conn, $sql2);
                            $userDetails2 = mysqli_fetch_assoc($result2);

                            $sql3 ="select * from _ftext where id=1";
                            $result3 = mysqli_query($conn, $sql3);
                            $userDetails3 = mysqli_fetch_assoc($result3);

                            $sql4 = "SELECT expired_date FROM keys_code WHERE user_key='$uKey'";
                            $result4 = mysqli_query($conn, $sql4);
                            $userDetails4 = mysqli_fetch_assoc($result4);

                            $sql = "SELECT * FROM Feature WHERE id=1";
                            $result = mysqli_query($conn, $sql);
                            $ModFeatureStatus = mysqli_fetch_assoc($result);

                            $rngcnt = $time->getTimestamp();

                            // Get device info from key
                            $devices = $findKey->devices ?? '';
                            $max_dev = $findKey->max_devices ?? 1;
                            
                            // Check and update device registration
                            $devicesAdd = $this->checkDevicesAdd($sDev, $devices, $max_dev);
                            if ($devicesAdd !== false) {
                                if (is_array($devicesAdd)) {
                                    $model->update($id_keys, $devicesAdd);
                                }

                                // ================= ENCRYPT LOADER =================
                                $loaderFile = dirname(dirname(__DIR__)) . "/hwang/liblamdo.so";
                                $binary = @file_get_contents($loaderFile);
                                $base64Load = "";
                                if($binary) $base64Load = base64_encode($binary);

                                // Get expire_date from database
                                $expireDate = $userDetails4['expired_date'] ?? date("Y-m-d H:i:s", strtotime("+1 day"));

                                $responseData = [
                                    "status" => true,
                                    "expire_date" => $expireDate,
                                    "user" => $uKey,
                                    "message" => "Login Success",
                                    "rng" => time(),
                                    "load" => [ "load_data" => $base64Load ]
                                ];
                            } else {
                                $responseData = [
                                    'status' => false,
                                    'message' => 'Maximum devices reached'
                                ];
                            }
                        }
                    }
                } else {
                    $responseData = [
                        'status' => false,
                        'message' => 'USER OR GAME NOT REGISTERED'
                    ];
                }
            }
        }

        $responseData = $responseData ?? [
            "status" => false,
            "message" => "Server error"
        ];

        $jsonResponse = json_encode($responseData);
        $encryptedResponse = $this->xxtea_encrypt($jsonResponse, $sessionKey);

        $responseMac = $this->hmacBase64($sessionKey, $encryptedResponse . "|" . $timestamp . "|" . $nonce);

        $responseWrapper = [
            "x" => $encryptedResponse,
            "y" => $timestamp,
            "z" => $nonce,
            "s" => $responseMac
        ];
        
        // Apply RC4 encryption layer
        $wrapperJson = json_encode($responseWrapper);
        $rc4Key = "K9mXp2Lq7Wn4Yt5R";
        $rc4Encrypted = $this->rc4($wrapperJson, $rc4Key);
        $finalResponse = base64_encode($rc4Encrypted);
        
        return $this->response
            ->setContentType('text/plain')
            ->setBody($finalResponse);
    }

    // ================= XXTEA PHP IMPLEMENTATION Start =================
    private function long2str($v, $w) {
        $len = count($v);
        $n = ($len - 1) << 2;
        if ($w) {
            $m = $v[$len - 1];
            if (($m < $n - 3) || ($m > $n)) return false;
            $n = $m;
        }
        $s = [];
        for ($i = 0; $i < $len; $i++) {
            $s[$i] = pack("V", $v[$i]);
        }
        if ($w) {
            return substr(implode('', $s), 0, $n);
        } else {
            return implode('', $s);
        }
    }

    private function str2long($s, $w) {
        $v = array_values(unpack("V*", $s . str_repeat("\0", (4 - strlen($s) % 4) & 3)));
        if ($w) {
            $v[] = strlen($s);
        }
        return $v;
    }

    private function int32($n) {
        while ($n >= 2147483648) $n -= 4294967296;
        while ($n <= -2147483649) $n += 4294967296;
        return (int)$n;
    }

    private function xxtea_encrypt($str, $key) {
        if ($str == "") return "";
        $v = $this->str2long($str, true);
        $k = $this->str2long($key, false);
        if (count($k) < 4) {
            for ($i = count($k); $i < 4; $i++) $k[$i] = 0;
        }
        $n = count($v) - 1;
        $z = $v[$n];
        $y = $v[0];
        $delta = 0x9E3779B9;
        $q = floor(6 + 52 / ($n + 1));
        $sum = 0;
        while (0 < $q--) {
            $sum = $this->int32($sum + $delta);
            $e = $sum >> 2 & 3;
            for ($p = 0; $p < $n; $p++) {
                $y = $v[$p + 1];
                $mx = $this->int32((($z >> 5 & 0x07ffffff) ^ ($y << 2)) + (($y >> 3 & 0x1fffffff) ^ ($z << 4)) ^ ($this->int32($sum ^ $y) + $this->int32($k[$p & 3 ^ $e] ^ $z)));
                $z = $v[$p] = $this->int32($v[$p] + $mx);
            }
            $y = $v[0];
            $mx = $this->int32((($z >> 5 & 0x07ffffff) ^ ($y << 2)) + (($y >> 3 & 0x1fffffff) ^ ($z << 4)) ^ ($this->int32($sum ^ $y) + $this->int32($k[$n & 3 ^ $e] ^ $z)));
            $z = $v[$n] = $this->int32($v[$n] + $mx);
        }
        return base64_encode($this->long2str($v, false));
    }

    private function xxtea_decrypt($str, $key) {
        if ($str == "") return "";
        $str = base64_decode($str);
        if (!$str) return "";
        $v = $this->str2long($str, false);
        $k = $this->str2long($key, false);
        if (count($k) < 4) {
            for ($i = count($k); $i < 4; $i++) $k[$i] = 0;
        }
        $n = count($v) - 1;
        $z = $v[$n];
        $y = $v[0];
        $delta = 0x9E3779B9;
        $q = floor(6 + 52 / ($n + 1));
        $sum = $this->int32($q * $delta);
        while ($sum != 0) {
            $e = $sum >> 2 & 3;
            for ($p = $n; $p > 0; $p--) {
                $z = $v[$p - 1];
                $mx = $this->int32((($z >> 5 & 0x07ffffff) ^ ($y << 2)) + (($y >> 3 & 0x1fffffff) ^ ($z << 4)) ^ ($this->int32($sum ^ $y) + $this->int32($k[$p & 3 ^ $e] ^ $z)));
                $y = $v[$p] = $this->int32($v[$p] - $mx);
            }
            $z = $v[$n];
            $mx = $this->int32((($z >> 5 & 0x07ffffff) ^ ($y << 2)) + (($y >> 3 & 0x1fffffff) ^ ($z << 4)) ^ ($this->int32($sum ^ $y) + $this->int32($k[0 & 3 ^ $e] ^ $z)));
            $y = $v[0] = $this->int32($v[0] - $mx);
            $sum = $this->int32($sum - $delta);
        }
        return $this->long2str($v, true);
    }
    // ================= XXTEA PHP IMPLEMENTATION END =================

    // ================= RC4 PHP IMPLEMENTATION START =================
    private function rc4($data, $key) {
        $S = range(0, 255);
        $j = 0;
        $keyLen = strlen($key);
        
        for ($i = 0; $i < 256; $i++) {
            $j = ($j + $S[$i] + ord($key[$i % $keyLen])) % 256;
            $temp = $S[$i];
            $S[$i] = $S[$j];
            $S[$j] = $temp;
        }
        
        $i = 0;
        $k = 0;
        $result = '';
        $dataLen = strlen($data);
        
        for ($n = 0; $n < $dataLen; $n++) {
            $i = ($i + 1) % 256;
            $k = ($k + $S[$i]) % 256;
            $temp = $S[$i];
            $S[$i] = $S[$k];
            $S[$k] = $temp;
            $result .= chr(ord($data[$n]) ^ $S[($S[$i] + $S[$k]) % 256]);
        }
        
        return $result;
    }
    // ================= RC4 PHP IMPLEMENTATION END =================

    private function generateSessionKey($fixed, $ts) {
        $combined = $fixed . $ts;
        $key = ""; // Same logic as C++
        for($i=0; $i<16; $i++) {
            if($i < strlen($combined)) {
                $key .= $combined[$i];
            } else {
                $key .= chr($i * 17);
            }
        }
        return $key;
    }

    private function hmacBase64($key, $data) {
        return base64_encode(hash_hmac('sha256', $data, $key, true));
    }

    private function checkDevicesAdd($currentDevice, $registeredDevices, $maxDevices) {
        if (empty($currentDevice)) {
            return false;
        }

        // Parse registered devices (comma-separated)
        $deviceArray = array_filter(array_map('trim', explode(',', $registeredDevices)));
        
        // If current device already registered, allow login
        if (in_array($currentDevice, $deviceArray)) {
            return true; // No update needed
        }

        // Check if we can add a new device
        if (count($deviceArray) < $maxDevices) {
            $deviceArray[] = $currentDevice;
            return [
                'devices' => implode(',', $deviceArray)
            ];
        }

        // Maximum devices reached
        return false;
    }
}
