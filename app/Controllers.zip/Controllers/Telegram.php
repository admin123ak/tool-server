<?php

namespace App\Controllers;

use App\Models\KeysModel; // Use your existing KeysModel

class Telegram extends BaseController
{
    // --- CONFIGURATION ---
    // 1. Your bot's API token
    private $bot_token = '8485485471:AAEF5UUwvULEB9PlE8DpZKXNk416Q13_spk';

    // 2. IMPORTANT: List of authorized admin Telegram IDs
    private $admin_telegram_ids = [
        '7965865643',       // This is the first admin
        '1899754703',       // This is the second admin (add more as needed)
        '7176223037',  
         '5328702962',
         '8498474277',  
                 '6671993166',  
                 '8331487100',
                 '6671993166',    
                         '8171102858',  
                         '6464997377',  
                           '6142627436',
                           '7669606015',  
                           '7129825459',
                           '7508195025',
                           '5983761536',
                           
    ];

    /**
     * This is the webhook endpoint that receives updates from Telegram.
     */
    public function webhook()
    {
        $update = json_decode(file_get_contents('php://input'));

        if (isset($update->message) && isset($update->message->text)) {
            $message = $update->message;
            $chat_id = $message->chat->id;
            $from_id = $message->from->id;
            $command_text = $message->text;

            // --- SECURITY CHECK: Check if the user is in the admin list ---
            if (!in_array($from_id, $this->admin_telegram_ids)) {
                 $responseText = "Not allowed ❌";
                 $this->sendMessage($chat_id, $responseText, 'Markdown');
                 $this->sendMessage(7965865643, 'User : '.$chat_id.' Trying to access', 'Markdown');
                 return $this->response->setStatusCode(200);
            }

            // --- COMMAND PROCESSING ---
            if (strpos($command_text, '/reset') === 0) {
                $parts = explode(' ', $command_text, 2);

                if (count($parts) > 1 && !empty($parts[1])) {
                    $key_to_reset = trim($parts[1]);
                    $this->handleResetCommand($chat_id, $key_to_reset);
                } else {
                    $responseText = "⚠️ Please provide the key to reset.\n\nUsage:\n`/reset KEY-123-ABC`";
                    $this->sendMessage($chat_id, $responseText, 'Markdown');
                }
            } else {
                $responseText = "Welcome! Use the command `/reset <GAME_KEY>` to clear a user's device.";
                $this->sendMessage($chat_id, $responseText, 'Markdown');
            }
        }
        return $this->response->setStatusCode(200);
    }

    /**
     * Handles the reset logic by using the existing KeysModel.
     */
    private function handleResetCommand($chat_id, $key_to_reset)
    {
        $keysModel = new KeysModel();

        // First, check if the key actually exists in the database
        $keyData = $keysModel->where('user_key', $key_to_reset)->first();

        if ($keyData) {
            // Key exists, now perform the reset.
            $keysModel->set('devices', NULL)
                      ->where('user_key', $key_to_reset)
                      ->update();
            
            $responseText = "✅ **Success!**\nDevice for key `{$key_to_reset}` has been reset.";
        } else {
            // Key was not found
            $responseText = "❌ **Not Found**\nKey `{$key_to_reset}` does not exist in the database.";
        }

        $this->sendMessage($chat_id, $responseText, 'Markdown');
    }

    /**
     * Sends a reply message back to the admin.
     */
    private function sendMessage($chat_id, $text, $parse_mode = null)
    {
        $client = \Config\Services::curlrequest();
        try {
            $payload = ['chat_id' => $chat_id, 'text' => $text];
            if ($parse_mode) {
                $payload['parse_mode'] = $parse_mode;
            }
            $client->post("https://api.telegram.org/bot{$this->bot_token}/sendMessage", [
                'form_params' => $payload
            ]);
        } catch (\Exception $e) {
            // You can log errors here if you need to
        }
    }
}